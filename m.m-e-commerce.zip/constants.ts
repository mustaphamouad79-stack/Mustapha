
import { Language, Product, TranslationStrings } from './types';

export const WHATSAPP_NUMBER = '212710211532';

export const TRANSLATIONS: Record<Language, TranslationStrings> = {
  [Language.EN]: {
    home: 'Home',
    shop: 'Shop',
    cart: 'Cart',
    login: 'Login',
    addToCart: 'Add to Cart',
    removeFromCart: 'Remove',
    total: 'Total',
    checkout: 'Checkout',
    emptyCart: 'Your cart is empty',
    heroTitle: 'Elite Men\'s Sportswear',
    heroSub: 'Discover the latest from Nike, Adidas, and Lacoste.',
    shopNow: 'Shop Now',
    brandFilter: 'Brand',
    catFilter: 'Category',
    all: 'All',
    featured: 'Featured Products'
  },
  [Language.AR]: {
    home: 'الرئيسية',
    shop: 'المتجر',
    cart: 'السلة',
    login: 'تسجيل الدخول',
    addToCart: 'أضف للسلة',
    removeFromCart: 'إزالة',
    total: 'المجموع',
    checkout: 'الدفع',
    emptyCart: 'سلتك فارغة',
    heroTitle: 'ملابس رياضية رجالية فاخرة',
    heroSub: 'اكتشف أحدث صيحات نايكي وأديداس ولاكوست.',
    shopNow: 'تسوق الآن',
    brandFilter: 'العلامة التجارية',
    catFilter: 'الفئة',
    all: 'الكل',
    featured: 'منتجات مميزة'
  },
  [Language.FR]: {
    home: 'Accueil',
    shop: 'Boutique',
    cart: 'Panier',
    login: 'Connexion',
    addToCart: 'Ajouter au Panier',
    removeFromCart: 'Supprimer',
    total: 'Total',
    checkout: 'Commander',
    emptyCart: 'Votre panier est vide',
    heroTitle: 'Vêtements de Sport Élite',
    heroSub: 'Découvrez le dernier cri de Nike, Adidas et Lacoste.',
    shopNow: 'Acheter Maintenant',
    brandFilter: 'Marque',
    catFilter: 'Catégorie',
    all: 'Tous',
    featured: 'Produits Phares'
  }
};

export const PRODUCTS: Product[] = [
  {
    id: '1',
    name: {
      en: 'Nike Dri-FIT Legend T-Shirt',
      ar: 'تي شيرت نايكي دراي فيت ليجند',
      fr: 'T-shirt Nike Dri-FIT Legend'
    },
    description: {
      en: 'High-performance athletic t-shirt for daily workouts.',
      ar: 'تي شيرت رياضي عالي الأداء للتمارين اليومية.',
      fr: 'T-shirt athlétique haute performance pour vos entraînements quotidiens.'
    },
    price: 350,
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=600',
    category: 'T-Shirts',
    brand: 'Nike',
    sizes: ['S', 'M', 'L', 'XL']
  },
  {
    id: '2',
    name: {
      en: 'Adidas Essentials Hoodie',
      ar: 'هودي أديداس إيسنشلز',
      fr: 'Sweat à Capuche Adidas Essentials'
    },
    description: {
      en: 'Classic 3-Stripes hoodie made for comfort and style.',
      ar: 'هودي كلاسيكي بثلاثة خطوط مصمم للراحة والأناقة.',
      fr: 'Sweat à capuche classique à 3 bandes conçu pour le confort et le style.'
    },
    price: 650,
    image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&q=80&w=600',
    category: 'Hoodies',
    brand: 'Adidas',
    sizes: ['M', 'L', 'XL']
  },
  {
    id: '3',
    name: {
      en: 'Lacoste Slim Fit Polo',
      ar: 'بولو لاكوست سليم فيت',
      fr: 'Polo Lacoste Slim Fit'
    },
    description: {
      en: 'Timeless piqué cotton polo with the signature crocodile logo.',
      ar: 'قميص بولو من قطن بيكيه مع شعار التمساح الشهير.',
      fr: 'Polo intemporel en coton piqué avec le logo crocodile signature.'
    },
    price: 890,
    image: 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?auto=format&fit=crop&q=80&w=600',
    category: 'T-Shirts',
    brand: 'Lacoste',
    sizes: ['S', 'M', 'L', 'XL', 'XXL']
  },
  {
    id: '4',
    name: {
      en: 'Nike Pro Training Tracksuit',
      ar: 'بدلة تدريب نايكي برو',
      fr: 'Survەتمنٹ d\'entraînement Nike Pro'
    },
    description: {
      en: 'Elite level tracksuit for professional performance.',
      ar: 'بدلة رياضية من النخبة للأداء الاحترافي.',
      fr: 'Survêtement de niveau élite pour des performances professionnelles.'
    },
    price: 1200,
    image: 'https://images.unsplash.com/photo-1483721310020-03333e577078?auto=format&fit=crop&q=80&w=600',
    category: 'Tracksuits',
    brand: 'Nike',
    sizes: ['M', 'L', 'XL']
  },
  {
    id: '5',
    name: {
      en: 'Adidas Ultraboost Shorts',
      ar: 'شورت أديداس ألترابوست',
      fr: 'Short Adidas Ultraboost'
    },
    description: {
      en: 'Breathable running shorts with moisture-wicking technology.',
      ar: 'شورت جري جيد التهوية بتقنية طرد الرطوبة.',
      fr: 'Short de course respirant avec technologie d\'évacuation de l\'humidité.'
    },
    price: 420,
    image: 'https://images.unsplash.com/photo-1591195853828-11db59a44f6b?auto=format&fit=crop&q=80&w=600',
    category: 'Tracksuits',
    brand: 'Adidas',
    sizes: ['S', 'M', 'L']
  },
  {
    id: '6',
    name: {
      en: 'Lacoste Sport Cap',
      ar: 'قبعة لاكوست الرياضية',
      fr: 'Casquette Lacoste Sport'
    },
    description: {
      en: 'Classic adjustable cap for on and off the court style.',
      ar: 'قبعة كلاسيكية قابلة للتعديل لأناقة داخل وخارج الملعب.',
      fr: 'Casquette classique réglable pour un style sur et en dehors du court.'
    },
    price: 280,
    image: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&q=80&w=600',
    category: 'Accessories',
    brand: 'Lacoste',
    sizes: ['One Size']
  }
];
