
export enum Language {
  EN = 'en',
  AR = 'ar',
  FR = 'fr'
}

export type Category = 'T-Shirts' | 'Hoodies' | 'Tracksuits' | 'Accessories';
export type Brand = 'Nike' | 'Adidas' | 'Lacoste' | 'Puma';

export interface Product {
  id: string;
  name: Record<Language, string>;
  description: Record<Language, string>;
  price: number;
  image: string;
  category: Category;
  brand: Brand;
  sizes: string[];
}

export interface CartItem extends Product {
  quantity: number;
  selectedSize: string;
}

export interface TranslationStrings {
  home: string;
  shop: string;
  cart: string;
  login: string;
  addToCart: string;
  removeFromCart: string;
  total: string;
  checkout: string;
  emptyCart: string;
  heroTitle: string;
  heroSub: string;
  shopNow: string;
  brandFilter: string;
  catFilter: string;
  all: string;
  featured: string;
}
