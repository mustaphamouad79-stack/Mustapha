
import React, { useState, useMemo, useEffect } from 'react';
import { Language, Product, CartItem, Category, Brand } from './types';
import { PRODUCTS, TRANSLATIONS } from './constants';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductCard from './components/ProductCard';
import CartDrawer from './components/CartDrawer';
import WhatsAppButton from './components/WhatsAppButton';

const App: React.FC = () => {
  const [lang, setLang] = useState<Language>(Language.EN);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<Category | 'All'>('All');
  const [activeBrand, setActiveBrand] = useState<Brand | 'All'>('All');

  const t = useMemo(() => TRANSLATIONS[lang], [lang]);
  const isRtl = lang === Language.AR;

  // Change body direction when language changes
  useEffect(() => {
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang, isRtl]);

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(p => {
      const catMatch = activeCategory === 'All' || p.category === activeCategory;
      const brandMatch = activeBrand === 'All' || p.brand === activeBrand;
      return catMatch && brandMatch;
    });
  }, [activeCategory, activeBrand]);

  const addToCart = (product: Product, selectedSize: string) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === product.id && i.selectedSize === selectedSize);
      if (existing) {
        return prev.map(i => 
          i.id === product.id && i.selectedSize === selectedSize 
            ? { ...i, quantity: i.quantity + 1 } 
            : i
        );
      }
      return [...prev, { ...product, quantity: 1, selectedSize }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string, size: string) => {
    setCart(prev => prev.filter(i => !(i.id === id && i.selectedSize === size)));
  };

  const categories: (Category | 'All')[] = ['All', 'T-Shirts', 'Hoodies', 'Tracksuits', 'Accessories'];
  const brands: (Brand | 'All')[] = ['All', 'Nike', 'Adidas', 'Lacoste'];

  return (
    <div className={`min-h-screen pb-20 transition-all duration-300 bg-[#fdfdfd]`}>
      <Navbar 
        lang={lang} 
        t={t} 
        cartCount={cart.reduce((a, b) => a + b.quantity, 0)} 
        onLanguageChange={setLang}
        onOpenCart={() => setIsCartOpen(true)}
      />

      <Hero t={t} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col space-y-8 mb-16">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-gray-100 pb-8">
            <div className="flex flex-wrap items-center gap-4">
              <span className="text-[10px] font-black uppercase text-gray-300 tracking-[0.3em]">{t.catFilter}</span>
              <div className="flex flex-wrap gap-2">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-6 py-2 rounded-none text-[10px] font-black uppercase tracking-widest transition-all ${
                      activeCategory === cat 
                        ? 'bg-red-600 text-white shadow-lg shadow-red-600/20' 
                        : 'bg-white text-gray-400 hover:text-black border border-gray-100'
                    }`}
                  >
                    {cat === 'All' ? t.all : cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <span className="text-[10px] font-black uppercase text-gray-300 tracking-[0.3em]">{t.brandFilter}</span>
              <div className="flex flex-wrap gap-2">
                {brands.map(brand => (
                  <button
                    key={brand}
                    onClick={() => setActiveBrand(brand)}
                    className={`px-6 py-2 rounded-none text-[10px] font-black uppercase tracking-widest transition-all ${
                      activeBrand === brand 
                        ? 'bg-black text-white shadow-xl' 
                        : 'bg-white text-gray-400 hover:text-black border border-gray-100'
                    }`}
                  >
                    {brand === 'All' ? t.all : brand}
                  </button>
                ))}
              </div>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-black italic uppercase tracking-tighter">
              {t.featured} <span className="text-red-600 text-sm align-top ml-2">[{filteredProducts.length}]</span>
            </h2>
            <div className="h-[2px] bg-red-600/10 flex-grow mx-8 hidden sm:block"></div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-10">
          {filteredProducts.map(product => (
            <ProductCard 
              key={product.id} 
              product={product} 
              lang={lang} 
              t={t} 
              onAddToCart={addToCart}
            />
          ))}
        </div>
      </main>

      <CartDrawer 
        isOpen={isCartOpen} 
        onClose={() => setIsCartOpen(false)} 
        items={cart} 
        lang={lang}
        t={t}
        onRemove={removeFromCart}
      />

      <WhatsAppButton lang={lang} />

      <footer className="mt-40 border-t border-gray-100 py-24 bg-black text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 text-[20rem] font-black text-white/5 italic tracking-tighter select-none pointer-events-none translate-y-[-20%] translate-x-[20%]">
          ELITE
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <div className="text-4xl font-black text-white mb-6 italic tracking-tighter">
            M.M <span className="text-red-600">ELITE</span>
          </div>
          <p className="text-gray-500 text-lg max-w-xl mx-auto mb-12 font-medium leading-relaxed uppercase tracking-tight">
            The destination for high-performance sportswear. Nike, Adidas, Lacoste, and more. 
            Level up your game with the elite collection.
          </p>
          <div className="flex justify-center space-x-12 mb-16">
            <a href="#" className="text-gray-400 hover:text-red-600 transition-all transform hover:scale-125"><i className="fab fa-instagram text-3xl"></i></a>
            <a href="#" className="text-gray-400 hover:text-red-600 transition-all transform hover:scale-125"><i className="fab fa-facebook text-3xl"></i></a>
            <a href="#" className="text-gray-400 hover:text-red-600 transition-all transform hover:scale-125"><i className="fab fa-twitter text-3xl"></i></a>
            <a href="#" className="text-gray-400 hover:text-red-600 transition-all transform hover:scale-125"><i className="fab fa-tiktok text-3xl"></i></a>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-left mb-16 max-w-4xl mx-auto border-t border-white/10 pt-16">
            <div>
              <h4 className="font-black uppercase tracking-widest text-xs mb-6 text-red-600">Company</h4>
              <ul className="space-y-3 text-sm text-gray-400 font-bold uppercase tracking-tighter">
                <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Stores</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-black uppercase tracking-widest text-xs mb-6 text-red-600">Support</h4>
              <ul className="space-y-3 text-sm text-gray-400 font-bold uppercase tracking-tighter">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Shipping</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Returns</a></li>
              </ul>
            </div>
            <div className="col-span-2">
              <h4 className="font-black uppercase tracking-widest text-xs mb-6 text-red-600">Stay Updated</h4>
              <div className="flex">
                <input type="email" placeholder="YOUR EMAIL" className="bg-white/5 border border-white/10 px-4 py-3 text-sm w-full outline-none focus:border-red-600 transition-colors rounded-none" />
                <button className="bg-red-600 px-6 py-3 font-black text-xs uppercase tracking-widest">Join</button>
              </div>
            </div>
          </div>

          <p className="text-gray-600 text-[10px] tracking-[0.5em] uppercase font-black">
            &copy; 2024 M.M Elite Sportswear. Engineered for the Best.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default App;
