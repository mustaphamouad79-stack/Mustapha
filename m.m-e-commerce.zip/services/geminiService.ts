
import { GoogleGenAI, Type } from "@google/genai";
import { Language } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAIPromotion = async (productName: string, lang: Language): Promise<string> => {
  if (!process.env.API_KEY) return "Limited offer: Premium Quality!";

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a short, catchy 1-sentence marketing catchphrase for a sportswear item called "${productName}" in ${lang === Language.EN ? 'English' : lang === Language.AR ? 'Arabic' : 'French'}. Keep it professional and exciting.`,
    });
    return response.text || "Exclusive Collection!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "New Arrival!";
  }
};
