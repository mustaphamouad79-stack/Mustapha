
import React from 'react';
import { WHATSAPP_NUMBER } from '../constants';
import { Language } from '../types';

interface WhatsAppButtonProps {
  lang: Language;
}

const WhatsAppButton: React.FC<WhatsAppButtonProps> = ({ lang }) => {
  const isRtl = lang === Language.AR;
  const message = lang === Language.AR ? 'السلام عليكم، أريد الاستفسار عن بعض الملابس' : 'Bonjour, je souhaite me renseigner sur certains articles.';
  const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className={`fixed bottom-8 ${isRtl ? 'left-8' : 'right-8'} z-[60] bg-[#25D366] text-white w-14 h-14 rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform active:scale-95 group overflow-hidden`}
    >
      <i className="fab fa-whatsapp text-3xl"></i>
      <div className={`absolute ${isRtl ? 'right-full mr-4' : 'left-full ml-4'} whitespace-nowrap bg-black text-white px-4 py-2 text-xs font-black uppercase tracking-widest rounded-none opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none`}>
        {lang === Language.AR ? 'تواصل معنا' : lang === Language.FR ? 'Contactez-nous' : 'Chat with us'}
      </div>
    </a>
  );
};

export default WhatsAppButton;
