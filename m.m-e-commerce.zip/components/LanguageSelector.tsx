
import React from 'react';
import { Language } from '../types';

interface LanguageSelectorProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({ currentLang, onLanguageChange }) => {
  const languages = [
    { code: Language.EN, label: 'EN', name: 'English' },
    { code: Language.AR, label: 'AR', name: 'العربية' },
    { code: Language.FR, label: 'FR', name: 'Français' },
  ];

  return (
    <div className="flex space-x-2 items-center">
      {languages.map((lang) => (
        <button
          key={lang.code}
          onClick={() => onLanguageChange(lang.code)}
          className={`px-2 py-1 text-xs font-bold rounded border transition-colors ${
            currentLang === lang.code
              ? 'bg-black text-white border-black'
              : 'bg-white text-black border-gray-300 hover:border-black'
          }`}
          title={lang.name}
        >
          {lang.label}
        </button>
      ))}
    </div>
  );
};

export default LanguageSelector;
