
import React, { useState, useEffect } from 'react';
import { Product, Language, TranslationStrings } from '../types';
import { getAIPromotion } from '../services/geminiService';

interface ProductCardProps {
  product: Product;
  lang: Language;
  t: TranslationStrings;
  onAddToCart: (product: Product, size: string) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, lang, t, onAddToCart }) => {
  const [promo, setPromo] = useState<string>("");
  const [selectedSize, setSelectedSize] = useState(product.sizes[0]);

  useEffect(() => {
    getAIPromotion(product.name[lang], lang).then(setPromo);
  }, [product.name, lang]);

  return (
    <div className="group bg-white rounded-none shadow-sm hover:shadow-2xl transition-all duration-500 border border-gray-100 flex flex-col h-full overflow-hidden">
      <div className="relative aspect-[4/5] overflow-hidden bg-gray-50">
        <img
          src={product.image}
          alt={product.name[lang]}
          className="w-full h-full object-cover grayscale-[0.3] group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
        />
        <div className="absolute top-4 left-4 bg-black text-white px-3 py-1 text-[10px] uppercase font-black tracking-[0.2em]">
          {product.brand}
        </div>
        {product.price > 800 && (
          <div className="absolute top-4 right-4 bg-red-600 text-white px-2 py-1 text-[10px] uppercase font-black tracking-widest">
            Premium
          </div>
        )}
      </div>

      <div className="p-6 flex flex-col flex-grow">
        <div className="mb-3">
          <p className="text-[11px] text-red-600 font-black uppercase tracking-widest mb-1">
            {product.category}
          </p>
          <h3 className="text-xl font-black text-gray-900 leading-tight uppercase italic tracking-tight">
            {product.name[lang]}
          </h3>
          <p className="text-xs text-gray-400 font-bold uppercase mt-2 tracking-tighter line-clamp-1">
            {promo || "Sport performance elite"}
          </p>
        </div>
        
        <p className="text-sm text-gray-500 mb-6 font-medium leading-relaxed">
          {product.description[lang]}
        </p>

        <div className="mt-auto">
          <div className="flex flex-wrap gap-2 mb-6">
            {product.sizes.map((size) => (
              <button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`min-w-[40px] h-10 px-2 text-[10px] font-black border transition-all ${
                  selectedSize === size
                    ? 'bg-black text-white border-black'
                    : 'bg-white text-gray-400 border-gray-200 hover:border-black hover:text-black'
                }`}
              >
                {size}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-gray-50">
            <span className="text-2xl font-black text-gray-900 tracking-tighter">{product.price} <small className="text-sm">MAD</small></span>
            <button
              onClick={() => onAddToCart(product, selectedSize)}
              className="bg-red-600 text-white w-12 h-12 rounded-full flex items-center justify-center hover:bg-black transition-all transform hover:rotate-12 active:scale-90"
              title={t.addToCart}
            >
              <i className="fas fa-cart-plus text-lg"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
