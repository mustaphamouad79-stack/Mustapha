
import React from 'react';
import { TranslationStrings } from '../types';

interface HeroProps {
  t: TranslationStrings;
}

const Hero: React.FC<HeroProps> = ({ t }) => {
  return (
    <div className="relative bg-gray-950 text-white py-32 px-6 md:px-12 overflow-hidden mb-12">
      <div className="absolute inset-0 opacity-50 grayscale hover:grayscale-0 transition-all duration-1000">
        <img 
          src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=1600" 
          alt="Sports Training" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent"></div>
      </div>
      <div className="relative max-w-7xl mx-auto z-10 flex flex-col items-start text-left">
        <div className="bg-red-600 text-white px-4 py-1 text-sm font-black uppercase tracking-[0.3em] mb-6 inline-block skew-x-[-12deg]">
          NEW SEASON 2024
        </div>
        <h1 className="text-5xl md:text-8xl font-black mb-6 tracking-tighter leading-[0.9] uppercase italic max-w-4xl">
          {t.heroTitle}
        </h1>
        <p className="text-xl md:text-2xl text-gray-300 max-w-xl mb-10 leading-relaxed font-medium">
          {t.heroSub}
        </p>
        <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6">
          <button className="bg-red-600 text-white px-12 py-5 rounded-sm font-black uppercase tracking-widest hover:bg-red-700 transition-all transform hover:translate-y-[-2px] shadow-2xl shadow-red-600/20 active:scale-95">
            {t.shopNow}
          </button>
          <button className="border-2 border-white text-white px-12 py-5 rounded-sm font-black uppercase tracking-widest hover:bg-white hover:text-black transition-all transform hover:translate-y-[-2px] active:scale-95">
            View Trends
          </button>
        </div>
      </div>
      
      {/* Decorative Brand Bar */}
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-white flex items-center justify-around px-6 opacity-100 overflow-hidden skew-y-1 origin-left translate-y-6">
        <span className="text-black font-black italic tracking-tighter text-3xl opacity-20 hover:opacity-100 transition-opacity cursor-default">NIKE</span>
        <span className="text-black font-black italic tracking-tighter text-3xl opacity-20 hover:opacity-100 transition-opacity cursor-default">ADIDAS</span>
        <span className="text-black font-black italic tracking-tighter text-3xl opacity-20 hover:opacity-100 transition-opacity cursor-default">LACOSTE</span>
        <span className="text-black font-black italic tracking-tighter text-3xl opacity-20 hover:opacity-100 transition-opacity cursor-default hidden md:inline">PUMA</span>
        <span className="text-black font-black italic tracking-tighter text-3xl opacity-20 hover:opacity-100 transition-opacity cursor-default hidden lg:inline">REELBOK</span>
      </div>
    </div>
  );
};

export default Hero;
