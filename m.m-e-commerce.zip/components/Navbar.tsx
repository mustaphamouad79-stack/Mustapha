
import React from 'react';
import { Language, TranslationStrings } from '../types';
import LanguageSelector from './LanguageSelector';

interface NavbarProps {
  lang: Language;
  t: TranslationStrings;
  cartCount: number;
  onLanguageChange: (lang: Language) => void;
  onOpenCart: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ lang, t, cartCount, onLanguageChange, onOpenCart }) => {
  const isRtl = lang === Language.AR;

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="text-2xl font-black tracking-tighter text-black flex items-center">
              M.M <span className="text-red-600 ml-1 italic">ELITE</span>
            </div>
            <div className={`hidden md:flex ${isRtl ? 'mr-10 space-x-reverse space-x-8' : 'ml-10 space-x-8'} font-medium`}>
              <a href="#" className="text-gray-900 hover:text-red-600 transition-colors font-bold">{t.home}</a>
              <a href="#" className="text-gray-500 hover:text-red-600 transition-colors font-bold">{t.shop}</a>
              <a href="#" className="text-gray-500 hover:text-red-600 transition-colors font-bold">Brands</a>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <LanguageSelector currentLang={lang} onLanguageChange={onLanguageChange} />
            
            <button className="p-2 text-gray-400 hover:text-black transition-colors">
              <i className="fas fa-search text-lg"></i>
            </button>
            
            <button 
              onClick={onOpenCart}
              className="relative p-2 text-gray-400 hover:text-black transition-colors"
            >
              <i className="fas fa-shopping-bag text-lg"></i>
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 bg-red-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
