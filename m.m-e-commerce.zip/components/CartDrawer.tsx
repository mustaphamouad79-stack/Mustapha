
import React from 'react';
import { CartItem, Language, TranslationStrings } from '../types';
import { WHATSAPP_NUMBER } from '../constants';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  lang: Language;
  t: TranslationStrings;
  onRemove: (id: string, size: string) => void;
}

const CartDrawer: React.FC<CartDrawerProps> = ({ isOpen, onClose, items, lang, t, onRemove }) => {
  const total = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const isRtl = lang === Language.AR;

  const handleWhatsAppOrder = () => {
    if (items.length === 0) return;

    let message = lang === Language.AR 
      ? `طلب جديد من M.M ELITE:\n\n` 
      : `Nouvelle commande de M.M ELITE:\n\n`;

    items.forEach(item => {
      message += `• ${item.name[lang]} (${item.brand})\n`;
      message += `  Size: ${item.selectedSize} | Qty: ${item.quantity} | Price: ${item.price} MAD\n\n`;
    });

    message += `------------------\n`;
    message += `${t.total}: ${total} MAD`;

    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] overflow-hidden">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity" onClick={onClose}></div>
      
      <div className={`absolute inset-y-0 ${isRtl ? 'left-0' : 'right-0'} max-w-md w-full bg-white shadow-2xl flex flex-col transition-transform duration-300 ease-in-out`}>
        <div className="flex items-center justify-between p-8 border-b">
          <h2 className="text-2xl font-black italic uppercase tracking-tighter flex items-center">
            <i className={`fas fa-shopping-bag text-red-600 ${isRtl ? 'ml-4' : 'mr-4'}`}></i>
            {t.cart} <span className="ml-2 text-gray-300">[{items.length}]</span>
          </h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <i className="fas fa-times text-2xl"></i>
          </button>
        </div>

        <div className="flex-grow overflow-y-auto p-8 space-y-8">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-gray-300">
              <i className="fas fa-ghost text-7xl mb-6 opacity-10"></i>
              <p className="text-xl font-black uppercase italic tracking-widest">{t.emptyCart}</p>
            </div>
          ) : (
            items.map((item, idx) => (
              <div key={`${item.id}-${item.selectedSize}-${idx}`} className="flex space-x-6 items-start pb-8 border-b last:border-0 border-gray-50">
                <img src={item.image} alt={item.name[lang]} className="w-24 h-24 rounded-none object-cover grayscale-[0.5] hover:grayscale-0 transition-all" />
                <div className="flex-grow">
                  <div className="flex justify-between items-start">
                    <h3 className="font-black text-gray-900 leading-tight uppercase italic tracking-tighter">{item.name[lang]}</h3>
                    <button 
                      onClick={() => onRemove(item.id, item.selectedSize)}
                      className="text-gray-300 hover:text-red-600 transition-colors ml-2"
                    >
                      <i className="fas fa-trash-alt"></i>
                    </button>
                  </div>
                  <p className="text-[10px] text-gray-400 font-black uppercase mt-2 tracking-[0.2em]">
                    {item.brand} • SIZE {item.selectedSize}
                  </p>
                  <div className="flex items-center justify-between mt-4">
                    <span className="font-black text-lg">{item.price} <small className="text-xs">MAD</small></span>
                    <span className="text-xs bg-gray-100 px-2 py-1 font-bold">QTY: {item.quantity}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="p-8 border-t bg-white space-y-4">
          <div className="flex items-center justify-between mb-4">
            <span className="text-gray-400 font-black uppercase tracking-widest text-sm">{t.total}</span>
            <span className="text-4xl font-black tracking-tighter">{total} <small className="text-lg">MAD</small></span>
          </div>
          
          <button 
            onClick={handleWhatsAppOrder}
            disabled={items.length === 0}
            className={`w-full py-4 rounded-none font-black uppercase tracking-[0.2em] flex items-center justify-center transition-all bg-[#25D366] text-white hover:bg-[#128C7E] active:scale-95 shadow-xl shadow-green-600/20 disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            <i className="fab fa-whatsapp mr-3 text-xl"></i>
            {lang === Language.AR ? 'أطلب عبر واتساب' : lang === Language.FR ? 'Commander via WhatsApp' : 'Order via WhatsApp'}
          </button>

          <button 
            disabled={items.length === 0}
            className={`w-full py-4 rounded-none font-black uppercase tracking-[0.3em] flex items-center justify-center transition-all ${
              items.length > 0 
                ? 'bg-red-600 text-white hover:bg-black active:scale-95 shadow-xl shadow-red-600/20' 
                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
            }`}
          >
            {t.checkout}
            <i className={`fas ${isRtl ? 'fa-arrow-left mr-4' : 'fa-arrow-right ml-4'}`}></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default CartDrawer;
